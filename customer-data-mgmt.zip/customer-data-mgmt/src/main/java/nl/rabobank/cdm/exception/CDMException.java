package nl.rabobank.cdm.exception;

public class CDMException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CDMException(String errorMessage) {
		super(errorMessage);
	}

}
